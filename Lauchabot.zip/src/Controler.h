#ifndef CONTROLLER_H
#define CONTROLLER_H
#include <ArxContainer.h>
#include <limits>
#include <Arduino.h>
#define  DOUBLE_MAX std::numeric_limits<double>::max()
#define  DOUBLE_MIN std::numeric_limits<double>::min()

class PIDController{
private:
    double Kp;
    double Kd;
    double Ki;
    double *setpoint;
    double *control_variable;
    double *input;

    double control_variable_upper_limit;
    double control_variable_lower_limit;
;

    //Constant for low pass filter for error
    double lp_a;
    double filtered_error;

    //History
    int history_length;
    std::vector<unsigned long> delta_t_history;
    std::vector<double> error_history;

    double calculate_low_pass_filter(double new_error){
        filtered_error = filtered_error + (1 - lp_a) + new_error * lp_a;
    }

public:

    //Initialization
    PIDController(double *setpoint, double *control_variable, double *input, double Kp = 0.0,
        double Kd = 0.0, double Ki = 0.0, int history_length = 20, double lp_a = 0.0,
        double control_variable_lower_limit = DOUBLE_MIN, 
        double control_variable_upper_limit = DOUBLE_MAX){
        set_setpoint(setpoint);
        set_control_variable(control_variable);
        set_input(input);
        set_constants(Kd, Kp, Ki);
        set_history_length(history_length);
        set_lowpass_filter(lp_a);
        control_variable_limits(control_variable_lower_limit, control_variable_upper_limit);
    }
    void set_setpoint(double *setpoint){
        this -> setpoint = setpoint;
    }
    void set_control_variable(double *control_variable){
        this -> control_variable = control_variable;
    }
    void set_input(double *input){
        this -> input = input;
    }
    void set_constants(double Kp = 0.0, double Kd = 0.0, double Ki = 0.0){
        this -> Kp = Kp;
        this -> Kd = Kd;
        this -> Ki = Ki;
    }
    void set_history_length(int history_length){
        this -> history_length = history_length;
    }
    void set_lowpass_filter(double lp_a){
        this -> lp_a = lp_a;
    }
    void control_variable_limits(double control_variable_lower_limit, double control_variable_upper_limit){
        this -> control_variable_upper_limit = control_variable_upper_limit;
        this -> control_variable_lower_limit = control_variable_lower_limit;
    }

    void update_history(double new_delta_t, double new_error){
        //Reformular para no necesitar guardar todo el historial de valores y solo sumar al termino integral
        //Y guardar ultimos dos valores de la variable

        delta_t_history.push_back(new_delta_t);
        error_history.push_back(new_error);
        if (error_history.size() > history_length){
            error_history.erase(error_history.begin());
            delta_t_history.erase(delta_t_history.begin());
        }
    }
    void update_controller(unsigned long delta_t){
        // delta_t is the time increment since the last time called the method
        // Se podría manejar internamente esta variable la verdad
        double error = *setpoint - *input;
        //Update history
        update_history(delta_t, error);

        //Make one step for the control loop
        //https://www.betzler.physik.uni-osnabrueck.de/Manuskripte/Elektronik-Praktikum/p3/doc2558.pdf
        int n = error_history.size();
        //Proportional term
        double proportional_error = Kp * error_history[n - 1];
        //Diferential term
        double derivative_error = Kd * (error_history[n - 1] - error_history[n - 2]) / delta_t_history[n - 1];

        //Integral term
        double integral_error = 0.0; 
        for(size_t i = 0; i < error_history.size(); ++i){
            integral_error += error_history[i] * delta_t_history[i];
        }
        // //Antiwindup
        // if (Ki * integral_error > control_variable_upper_limit || Ki * integral_error < control_variable_lower_limit){
        //     integral_error = 0;
        // }
        double u = Kp * proportional_error + Kd *derivative_error + Ki * integral_error;

        constrain(u, control_variable_lower_limit, control_variable_upper_limit);

        *control_variable = u;
    }
};


#endif