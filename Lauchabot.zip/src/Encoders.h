#ifndef ENCODERS_H
#define ENCODERS_H

/*

Modulo para leer los Encoders

*/

#include "Pines.h"

//TODO: USAR PARA POSICION EN EL MAPA


int STEPS = 30 * 12;
volatile long count_L = 0;
volatile long count_R = 0;


void Read_Encoder_1_L(){
  
  if (digitalRead(C1_L) == HIGH) {
    if (digitalRead(C2_L) == LOW) {
      count_L++;
    } else {
      count_L--;
    }
  } else {
    if (digitalRead(C2_L) == LOW) {
      count_L--;
    } else {
      count_L++;
    }
  }
}

void Read_Encoder_2_L(){
  
  if (digitalRead(C2_L) == HIGH) {
    if (digitalRead(C1_L) == LOW) {
      count_L--;
    } else {
      count_L++;
    }
  } else {
    if (digitalRead(C1_L) == LOW) {
      count_L++;
    } else {
      count_L--;
    }
  }
}

void Read_Encoder_1_R(){
  
  if (digitalRead(C1_R) == HIGH) {
    if (digitalRead(C2_R) == LOW) {
      count_R--;
    } else {
      count_R++;
    }
  } else {
    if (digitalRead(C2_R) == LOW) {
      count_R++;
    } else {
      count_R--;
    }
  }
}

void Read_Encoder_2_R(){
  
  if (digitalRead(C2_R) == HIGH) {
    if (digitalRead(C1_R) == LOW) {
      count_R++;
    } else {
      count_R--;
    }
  } else {
    if (digitalRead(C1_R) == LOW) {
      count_R--;
    } else {
      count_R++;
    }
  }
}

#endif