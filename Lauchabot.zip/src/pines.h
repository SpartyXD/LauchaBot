#ifndef PINES_H
#define PINES_H

/*

Modulo para administrar de mejor manera los pines :D

*/

//Libraries
#include <Arduino.h>

//Macros
#define rep(i, n) for(int i=0; i<n; i++)


//=============================
//Pins
const int btnPin = 5;
const int btnPin2 = 0;
const int buzzerPin = 15;


//Sensores IR
const int SensorCount = 8;
const int sensorCentralPins[8] = {27, 26, 25, 33, 32, 34, 35, 39};

const int SensorCountL = 1;
const int sensorIzqPins[1] = {14};

const int SensorCountR = 1;
const int sensorDerPins[1] = {36};


//MOTORS
const int IN1_L = 23;
const int IN2_L = 19;

const int IN1_R = 2;
const int IN2_R = 12;

//ENCODERS
const int C1_L = 4;
const int C2_L = 16;

const int C1_R = 18;
const int C2_R = 17;


//Pin manager
const int INPUT_PINS[] = {C1_L, C1_R, C2_L, C2_R};

const int OUTPUT_PINS[] = {IN1_L, IN1_R, IN2_L, IN2_R};

const int N_INPUT = sizeof(INPUT_PINS)/sizeof(int);
const int N_OUTPUT = sizeof(OUTPUT_PINS)/sizeof(int);


//=============================
//Code

//Inicializar todos los pines de input_output que no sean objetos
void initPins(){
    rep(i, N_INPUT)
        pinMode(INPUT_PINS[i], INPUT);
    rep(i, N_OUTPUT)
        pinMode(OUTPUT_PINS[i], OUTPUT);  
}


#endif
