/*

Modulo que contiene el codigo principal del bot

*/

//Libs
#include <LauchaBot.h>
#include <BluetoothSerial.h>


//=============================
//GLOBALS
LauchaBot bot;

BluetoothSerial server;

//=============================
//FUNCTION DECLARATIONS

//Actualizar datos usando bluetooth
void updateData();

//Handler commandos
void handleCommand(String &command);

//Modo calibracion del bot (inicio del todo)
void calibrateMode();

//=============================
//MAIN CODE

void setup(){
    Serial.begin(115200);
    server.begin("LauchaBot");
    
    Serial.println("Iniciando lauchabot...\n");
    bot.init(true, 1000);
    bot.buzzer.startupBeep();

    delay(1000);

    //LAUCHA
    bot.buzzer.calibrateBeep();
    calibrateMode();
}


void loop(){
    //Revisar comandos nuevos por bluetooth
    updateData();

    //Bot existiendo.exe
    bot.run();
}


//=============================
//FUNCTION IMPLEMENTATION

//Estado antes de ser calibrado
void calibrateMode(){
    Serial.println("Listo para calibrarse!\n");

    //Esperar boton calibrar para empezar
    while(!bot.btn1.pressed()){
        updateData();
    } 

    //Calibrar bot
    bot.buzzer.actionBeep();
    Serial.println("Calibrando....");
    bot.calibrarse();

    //Imprimir y avisar al usuario
    Serial.println("Bot calibrado!\n");
    bot.sensor.printUmbrales();
    bot.buzzer.successBeep();
}


//Ver si hay datos nuevos por bluetooth
void updateData(){
    while(server.available()){
        String command = server.readStringUntil('\n');
        handleCommand(command);
    }
}


//Majear el comando recibido por bluetooth
void handleCommand(String &command){
    bot.buzzer.updateBeep();
    char letter = command[0];

    //STOP
    if(letter == 'X'){
        bot.endRace();
        Serial.println("STOP!");
        return;
    }

    double value = command.substring(1).toDouble();

    switch (letter)
    {
    case 'P':
        bot.setPID(value, -1, -1);
        break;
    case 'I':
        bot.setPID(-1, value, -1);
        break;
    case 'D':
        bot.setPID(-1, -1, value);
        break;
    //-----------------------
    case 'W':
        bot.setWhiteLines(bool(value));
        break;
    case 'B':
        bot.setSpeeds(value, -1, -1);
        break;
    case 'G':
        bot.setSpeeds(-1, -1, value);
        break;
    case 'M':
        bot.setSpeeds(-1, value, -1);
        break;
    //------------------------
    default:
        bot.setWeights(int(letter-'0'), int(value));
    }

}

//================================