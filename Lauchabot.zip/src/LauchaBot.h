#ifndef LAUCHA_BOT_H
#define LAUCHA_BOT_H

#include <Pines.h>
#include <Encoders.h>
#include <Objects.h>


//============================


//============================

/*
Clase para controlar facilmente todos los componentes del bot 
*/
class LauchaBot{
private: 
    //=================================
    //VARIABLES PID
    int pos_ideal = 0;

    double P, D, I, PID_val;
    double error = 0.0, last_error=0.0;

    double Kp = 0, Kd=0, Ki=0;

    //Para control integral
    std::vector<double> errors;
    int current_error_idx = 0;
    int ERROR_COUNT = 1000;

    //-------------------------
    //Velocidad
    double VEL_BASE = 0, VEL_MAX=0, VEL_GIRO=0;
    double VEL_MIN = -VEL_MAX;
    double vel_izq=VEL_BASE, vel_der=VEL_BASE;

    //=================================

    //Sensor central
    int weights[SensorCount] = {-3, -2, -1, 0, 0, 1, 2, 3};

    //Sensor Izq
    int weightsL[SensorCountL] = {0};

    //Sensor Der
    int weightsR[SensorCountR] = {0};

    //=================================

    //Flags para cruces

    unsigned long max_time = 3294967294;
    unsigned long last_end_check = 0;

    bool on_race = false;
    bool checking_end = false;

    //Si llega a 2 = termino de carrera
    int amount_of_rights = 0; 

    //================================


    //Giro abrupto en una direccion
    //@param sentido False = izquierda, True = derecha
    void giro_violento(bool sentido){
        if(sentido){
            //Derecha
            vel_izq = VEL_GIRO;
            vel_der = 0;
        }
        else{
            //Izquierda
            vel_izq = 0;
            vel_der = VEL_GIRO;
        }

        moverMotores(vel_izq, vel_der);
    }


    //Funcion interna del bot para controlar motores segun pos
    void control_PID(int pos){
        //Calcular error actual
        error = pos_ideal-pos;

        //Agregar a suma acumulada y avanzar indice
        errors[current_error_idx] = error;
        current_error_idx = (current_error_idx+1)%ERROR_COUNT;

        //Obtener valores del PID
        P = error;
        I = get_error_sum();
        D = error-last_error;

        PID_val = double(Kp*P) + double(Ki*I) + double(Kd*D);
        last_error = error;
        
        //Actualizar velocidades

        //Izquierda
        vel_izq = VEL_BASE - PID_val;
        vel_izq = constrain(vel_izq, VEL_MIN, VEL_MAX);

        //Derecha
        vel_der = VEL_BASE + PID_val;
        vel_der = constrain(vel_der, VEL_MIN, VEL_MAX);

        // Serial.println(String(vel_der) + String("\t") + String(vel_izq));
        moverMotores(vel_izq, vel_der);
    }




public:
    LauchaBot(){}

    //Objetos
    Boton btn1, btn2;
    Buzzer buzzer;
    LineSensor sensor, sensorL, sensorR;
    Motor motorL, motorR;

    //----------------------

    //Inicializar Bot
    void init(bool white_line=true, int error_count=1000){
        initPins();

        //Init error array
        ERROR_COUNT = error_count;
        errors.assign(ERROR_COUNT, 0.0);
        current_error_idx = 0;

        motorL.init(IN1_L, IN2_L);
        motorR.init(IN1_R, IN2_R);

        sensor.init(SensorCount, sensorCentralPins, weights, white_line);
        sensorL.init(SensorCountL, sensorIzqPins, weightsL, white_line);
        sensorR.init(SensorCountR, sensorDerPins, weightsR, white_line);

        btn1.init(btnPin);
        btn2.init(btnPin2);
        buzzer.init(buzzerPin);

        stopMotors();
    }


    //Rutina de calibracion
    void calibrarse(){
        Serial.println("=============================");
        Serial.println("Iniciando calibracion :D\n");


        //Obtener valores de la pista (manualmente hay que moverlo xd)
        rep(i, 5000){
          sensor.calibrate();
          sensorL.calibrate();
          sensorR.calibrate();
        }

        //Parar motores y obtener umbrales
        stopMotors();
        sensor.updateThresholds();
        sensorL.updateThresholds();
        sensorR.updateThresholds();

        //Mensajitos :p
        Serial.println("CALIBRACION COMPLETA!");
        sensor.printUmbrales();
    }


    //Reiniciar error y pos del bot
    void restart_error(){
        error = last_error = 0.0;
        errors.assign(ERROR_COUNT, 0.0);
    }


    //Obtener suma para control integral
    double get_error_sum(){
        double sum = 0.0;
        rep(i, ERROR_COUNT)
            sum += errors[i];
        return sum;
    }


    int GREAT_SPEED = 180;
    //Frenar al bot
    void stopMotors(){
        if(motorL.current_speed > GREAT_SPEED || motorR.current_speed > GREAT_SPEED){
            //Frenado mas potente
            moverMotores(-255, -255);
            delay(50);
        }
        moverMotores(0, 0);
    }


    //Setea nuevos valores para el PID del bot
    //Poner -1 si no se quiere modificar
    void setPID(double p=-1.0, double i=-1.0, double d=-1.0){
        //Update vals
        Kp= (p != -1.0) ? p : Kp;
        Ki= (i != -1.0) ? i : Ki;
        Kd= (d != -1.0) ? d : Kd;
    
        Serial.println("\nPID: ");
        Serial.print("P: "); Serial.println(Kp);
        Serial.print("I: "); Serial.println(Ki);
        Serial.print("D: "); Serial.println(Kd);
    }


    /*Actualiza los pesos del sensor central
    @param idx debe ser el idx del sensor desde 0
    @param val nuevo peso
    */
    void setWeights(int idx, int val){
        constrain(idx, 0, SensorCount-1);
        weights[idx] = val;
        sensor.updateWeights(weights);
        Serial.println("\nSeteado weight: " + String(idx) + String(" --> ") + String(val));
        Serial.print("\nPesos: ");
        rep(i, SensorCount)
            Serial.print(weights[i]); Serial.print(" ");
    }


    //Actualiza las velocidades del bot
    //-1 si no se quiere cambiar
    void setSpeeds(double base_speed=-1.0, double max_speed=-1.0, double turn_speed=-1.0){
        VEL_BASE = (base_speed != -1.0) ? base_speed : VEL_BASE;
        VEL_MAX = (max_speed != -1.0) ? max_speed : VEL_MAX;
        VEL_MIN = -VEL_MAX;
        VEL_GIRO = (turn_speed != -1.0) ? turn_speed : VEL_GIRO;

        Serial.print("\nVelocidades: ");
        Serial.print("BASE: "); Serial.println(VEL_BASE);
        Serial.print("MAX: "); Serial.println(VEL_MAX);
        Serial.print("GIRO: "); Serial.println(VEL_GIRO);
    }


    //Actualiza si los sensores deberian identificar linea blanca o negra
    void setWhiteLines(bool val=true){
        sensor.setWhiteLine(val);
        sensorL.setWhiteLine(val);
        sensorR.setWhiteLine(val);
        Serial.print("\nLINEA BLANCA: "); Serial.println(val);
    }

    //-----------------------------
    bool first_encounter = true;
    unsigned long END_DELAY = 130;
    //Funcion encargada de chequear los laterales
    //Llamar a updateReadings antes de esta :p
    void updateLandmarks(){
        unsigned long time_now = millis() % max_time;

        //Chequear si paso un tiempo decente
        if(time_now-last_end_check <= END_DELAY)
            return;

        last_end_check = time_now;
        //Ya me lo pille antes
        if(checking_end){
            if(sensorL.getSensorVal(0)){
                checking_end = false; //Abortar mision
            }

            else if(!sensorR.getSensorVal(0)){
                if(!first_encounter)
                    endRace(); //Fin de la carrera
                else{
                    checking_end = false; //Primera marca
                    first_encounter = false;
                }

            }
        }
        else if(sensorR.getSensorVal(0) && !sensorL.getSensorVal(0)){
            //Empezar cuenta regresiva para encontrar sensor izq..
            checking_end = true;
            last_end_check = time_now;
        }
    }


    //Estado standby
    void idleMode(){
        stopMotors(); //Detener ruedas
        
        //Esperar a boton 2 de nuevo para modo carrera nuevamente
        if(btn2.pressed()){
            buzzer.raceBeep();
            on_race = true; 
            delay(2000); //Breve pausa antes de partir
        }
    }


    //Modo carrera
    void raceMode(){
        //Actualizar todo
        updateReadings();
        updateLandmarks();

        //Chequear si finalizo carrera (landmark)
        if(!on_race)
            return;

        //Continuar carrera
        line_follow();
    }


    //Funcion que se encarga de administrar los modos del bot
    //Llamar dentro de loop continuamente
    void run(){
        Serial.println(on_race);

        //Chequear boton idle
        if(btn1.pressed()){
            buzzer.actionBeep();
            endRace();
            delay(1000);
        }

        //Modo idle / Modo carrera
        if(!on_race)
            idleMode();
        else
            raceMode();

    }


    //Actualizar todos los sensores
    void updateReadings(){
        sensor.updateSensors();
        sensorL.updateSensors();
        sensorR.updateSensors();
    }


    //Terminar carrera
    void endRace(){
        on_race = false;
        checking_end = false;
        amount_of_rights = 0;
        first_encounter = true;
        stopMotors();
        restart_error();
    }
    

    //Funcion siguelinea
    void line_follow(){
        int pos = sensor.getPos();
        control_PID(pos);
    }


    /*
    Mover solo un motor
    @param motor 0 = izquierdo, 1 = derecho
    @param speed velocidad en pwm
    */
    void moverMotor(int motor, double speed){
        if(motor == 0)
            motorL.move(speed);
        else
            motorR.move(speed);
    }


    //mover ambos motores (velocidades en pwm)
    void moverMotores(double leftPWM, double rightPWM){
        motorL.move(leftPWM);
        motorR.move(rightPWM);
    }


    //===================
    //Test componentes

    void test_motores(){
        Serial.println("AVANZANDO....");
        moverMotores(255, 255);
        delay(2000);

        Serial.println("PA ATRA....");
        moverMotores(-255, -255);
        delay(2000);

        Serial.println("STOP!\n");
        stopMotors();

        Serial.println("IZQUIERDO....");
        moverMotor(0, 255);
        delay(2000);
        moverMotor(0, -255);
        delay(2000);

        stopMotors();

        Serial.println("DERECHO....");
        moverMotor(1, 255);
        delay(2000);
        moverMotor(1, -255);
        delay(2000);

        Serial.println("STOP!\n");
        stopMotors();
    }


    void test_sensores(){
        Serial.println("SENSOR CENTRAL:");
        sensor.printReadings();
        Serial.println("===================");

        Serial.println("LATERAL IZQUIERDO:");
        sensorL.printReadings();
        Serial.println("===================");

        Serial.println("LATERAL DERECHO:");
        sensorR.printReadings();
        Serial.println("===================");
    }

};



#endif
