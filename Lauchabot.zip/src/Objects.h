#ifndef OBJECTS_H
#define OBJECTS_H

#include <Arduino.h>
#include <ArxContainer.h>


//===========================================================

//Clase para manejar de manera mas sencilla pulsadores PULL-UP simples
class Boton{
private:
    int pin;
    unsigned long last_check = 0;
    bool last_state = true;
    bool current_state = true;
    unsigned long debounceDELAY = 45;

public:
    Boton(){}

    //Inicializar boton @param pin
    void init(const int pin){
        this->pin = pin;
        pinMode(pin, INPUT);
        last_state = digitalRead(pin);
        last_check = millis();
    }


    //Esta presionado actualmente?
    bool pressed(){
        unsigned long time_now = millis();
        current_state = digitalRead(pin);

        if(time_now-last_check > debounceDELAY){
            if(last_state == HIGH && current_state == LOW){
                //Pressed
                last_check = time_now;
                last_state = current_state;
                return true;
            }
        }

        last_state = current_state;
        return false;
    }

};

//===========================================================

//Clase para interacturar con motores DC de manera sencilla
class Motor{
private:
  //Pins
  int A, B;

  //Min velocity for movement
  const int MIN_VEL = 80;
  const int MAX_VEL = 255;

  //Conversion constants
  const double RPM_TO_PWM = (255.0/1300.0);
  const double PWM_TO_RPM = (1.0/RPM_TO_PWM);

public:

    //Current speed
    int current_speed=0;

    Motor(){}

    //Inicializar motores
    //@param a pin A motor
    //@param b pint B motor
    void init(int a, int b){
        A = a; 
        pinMode(A, OUTPUT);

        B = b; 
        pinMode(B, OUTPUT);
    }


    //Mover motor con velocidad pwm
    void move(double val, bool rpm=false){
        val = constrain(val, -255.0, 255.0);

        if (val >=0.0){
            analogWrite(A, val);
            analogWrite(B, 0.0);
        }
        else{
            //Atras
            analogWrite(A, 0.0);
            analogWrite(B, -val);
        }

        current_speed = val;
    }

};

//===========================================================

//Clase para interactuar con buzzer
class Buzzer{

private:
    int pin;

public:

    Buzzer(){}

    //Inicializar buzzer @param pin
    void init(const int pin){
        this->pin = pin;
        pinMode(pin, OUTPUT);
    }

    //Funcion simple para que haga un ruido por un determinado tiempo
    //@param frec frecuencia del ruido
    //@param dur duracion del beep en millis
    void beep(int frec, unsigned long dur){
        tone(pin, frec);
        delay(dur);
        noTone(pin);
    }

    //Sonidos

    void calibrateBeep(){
        beep(700, 100);
        delay(50);
        beep(1000, 100);
        delay(50);
        beep(1300, 100);
        delay(150);
        beep(1000, 150);
    }

    void actionBeep(){
        beep(1000, 200);
    }

    void successBeep(){
        beep(700, 100);
        delay(50);
        beep(1000, 100);
        delay(50);
        beep(1300, 100);
    }

    //Beep modo insano
    void raceBeep(){
        int C5 = 523;  
        int E5 = 659;  
        int G5 = 784;  
        int A5 = 880; 
        int shortDuration = 200;
        int longDuration = 400; 

        beep(C5, shortDuration);
        beep(E5, shortDuration);
        beep(G5, longDuration-100);
        beep(C5, longDuration);   
    }


    //Beep modo crucero
    void chillBeep(){
        int C5 = 523;  
        int E5 = 659;  
        int G5 = 784;  
        int A5 = 880; 
        int shortDuration = 200;
        int longDuration = 400; 

    }


    //Beep modo curva fea
    void turnBeep(){

    }


    void startupBeep(){
        int C5 = 523;  
        int E5 = 659;  
        int G5 = 784;  
        int A5 = 880; 
        int shortDuration = 200;
        int longDuration = 400; 

        beep(C5, shortDuration);
        beep(E5, shortDuration);
        beep(G5, longDuration);
    }

    void updateBeep(){
        beep(650, 200);
        delay(50);
        beep(500, 200);
    }

};

//===========================================================

//Clase generica para sensores IR
class LineSensor{

private:
    //Arrays
    std::vector<int> pins;
    std::vector<int> weights;
    std::vector<int> linea;
    std::vector<int> fondo;
    std::vector<int> umbral;

    std::vector<int> sensorVals;

    //Vals
    int N;
    int min_pos=0, max_pos=0;
    int last_pos=0, ideal_pos=0;

    bool ONLINE = true;
    bool white_line=true;

    //FUNCIONES

    //FUNCION INTERNA: para inicializar los arrays de lecturas
    void initArrays(){
        pins.assign(N, 0);
        weights.assign(N, 0);
        linea.assign(N, 0);
        fondo.assign(N, 4096);
        umbral.assign(N, 0);
        sensorVals.assign(N, 0);
    }


    //FUNCION INTERNA: para traducir una lectura de analogo a digital
    int translateReading(int lecture, int threshold){
        int ans = 0;

        if(!white_line)
            ans = lecture >= threshold;
        else
            ans = lecture < threshold;

        return ans;
    }


    //FUNCION INTERNA: para traducir todas las lecutras a la vez del sensor
    void transformReadings(){
        rep(i, N)
            sensorVals[i] = translateReading(sensorVals[i], umbral[i]);
    }


    //FUNCION INTERNA: actualizar lecturas analogas de sensores
    void readSensors(){
        rep(i, N)
            sensorVals[i] = analogRead(pins[i]);
    }


public:

    LineSensor(){}

    /*
    Inicializar los pines de los sensores IR
    @param count cantidad de sensores
    @param pins array de tamaño <count> con los pines ordenados del IR
    @param weights arrray de tamaño <count> con los pesos a ponerle a cada sensor
    @param white_line XD
    */
    void init(int count, const int pins[], int weights[], bool white_line=true){
        //Set variables
        N = count;
        setWhiteLine(white_line);

        //Arrays
        initArrays();
        rep(i, N){
            //PinModes
            this->pins[i] = pins[i];
            pinMode(pins[i], INPUT);
        }

        updateWeights(weights);
    }

    //Actualizar todos los sensores y traducir lecturas analogas a digitales
    void updateSensors(){
        readSensors();
        transformReadings();
    }

    //Obtener el valor(digital) actual del pin <idx> del sensor (indexado de 0)
    int getSensorVal(int idx){
        idx = constrain(idx, 0, N-1);
        return sensorVals[idx];
    }

    /*Calibrar sensor: lee valores maximos y minimos para sacar umbrales
    Esta funcion se debe llamar varias veces para obtener valores decentes :p
    No olvidar despues llamar a updateThresholds() para aplicar cambios*/
    void calibrate(){
        //Obtener mediciones
        readSensors();
        
        //Agregar a maximos y minimos
        rep(i, N){
            linea[i] = max(sensorVals[i], linea[i]);
            fondo[i] = min(sensorVals[i], fondo[i]);
        }
    }


    //Calcular promedio entre maximos y minimos
    void updateThresholds(){
        rep(i, N)
            umbral[i] = (linea[i] + fondo[i])/2;
    }

    /*Actualizar pesos para el sensor 
    @param w array de tamaño <cant_sensores>con los nuevos pesos */
    void updateWeights(int w[]){
        rep(i, N)
            weights[i] = w[i];

        //Update max and min pos
        min_pos = 0;
        rep(i, N/2)
            min_pos += weights[i];
        max_pos = -min_pos;
    }

    //Actualizar si el sensor debe leer linea blanca o negra
    void setWhiteLine(bool val=true){
        white_line = val;
    }

    //Obtener posicion relativa con respecto a la linea
    int getPos(){
        //Actualizar variables
        ONLINE = false;
        int suma=0, pos=0, activeSensors=0;

        updateSensors();

        //Actualizar suma ponderada
        rep(i, N){
            suma += sensorVals[i]*weights[i];
            activeSensors += sensorVals[i];
        }

        //Obtener posicion
        pos = suma;
        // if(activeSensors != 0){
        //     //Dentro de linea
        //     pos = suma;
        //     pos = constrain(pos, min_pos, max_pos);
        //     ONLINE = true;
        // }
        // else{
        //     //FUERA DE LINEA XD
        //     if(last_pos < ideal_pos)
        //         pos = min_pos;
        //     else
        //         pos = max_pos;
        // }

        last_pos = pos;
        return pos;
    }


    void printUmbrales(){
        Serial.println("UMBRALES\n");

        Serial.println("FONDO:");
        rep(i, N)
            Serial.print(String(fondo[i]) + "\t");
        Serial.println("\n=============================");

        Serial.println("LINEA:");
        rep(i, N)
            Serial.print(String(linea[i]) + "\t");
        Serial.println("\n=============================");

        Serial.println("UMBRAL:");
        rep(i, N)
            Serial.print(String(umbral[i]) + "\t");
        Serial.println("\n=============================");
    }


    void printReadings(){
        updateSensors();
        rep(i, N)
            Serial.print(String(sensorVals[i]) + "\t");
        Serial.println(""); 
    }



};

//===========================================================


#endif